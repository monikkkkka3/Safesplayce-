-- Safesplayce Supabase Schema — Full Stack + Moderation
-- Run this in Supabase > SQL Editor > New Query > Paste > Run

-- Enable UUID
create extension if not exists "uuid-ossp";

-- ─────────────────────────────────────────────
-- PROFILES (extends auth.users)
-- ─────────────────────────────────────────────
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  email text,
  created_at timestamp with time zone default now()
);

-- ─────────────────────────────────────────────
-- ROOMS
-- ─────────────────────────────────────────────
create table if not exists rooms (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  code text, -- null = public, text = private code
  topic text,
  created_by uuid references profiles(id),
  max_members int default 12,
  is_live boolean default false,
  created_at timestamp with time zone default now(),
  expires_at timestamp with time zone default (now() + interval '24 hours')
);
alter table rooms enable row level security;
create policy "Anyone can read rooms" on rooms for select using (true);
create policy "Authenticated can create rooms" on rooms for insert with check (auth.role() = 'authenticated');
create policy "Anon can create rooms (demo)" on rooms for insert with check (true);

-- ─────────────────────────────────────────────
-- MESSAGES (realtime) — now with moderation flags
-- ─────────────────────────────────────────────
create table if not exists messages (
  id uuid primary key default uuid_generate_v4(),
  room_id uuid references rooms(id) on delete cascade not null,
  author_id uuid references profiles(id),
  display_name text not null,
  body text not null check (char_length(body) > 0 and char_length(body) < 500),
  is_hidden boolean default false, -- moderators can hide without deleting
  hidden_reason text,
  hidden_by text,
  created_at timestamp with time zone default now()
);
alter table messages enable row level security;
create policy "Anyone can read messages" on messages for select using (true);
create policy "Anyone can send messages (demo)" on messages for insert with check (true);
-- In production: with check (auth.uid() = author_id)

-- Enable realtime
alter publication supabase_realtime add table messages;
alter publication supabase_realtime add table rooms;

-- ─────────────────────────────────────────────
-- JOURNAL ENTRIES
-- ─────────────────────────────────────────────
create table if not exists journal_entries (
  id uuid primary key default uuid_generate_v4(),
  author_id uuid references profiles(id),
  display_name text,
  title text,
  body text not null,
  privacy text not null check (privacy in ('private','public')),
  is_flagged boolean default false,
  flagged_reason text,
  created_at timestamp with time zone default now()
);
alter table journal_entries enable row level security;
create policy "Public entries readable" on journal_entries for select using (privacy = 'public' or auth.uid() = author_id);
create policy "Anyone can insert journal (demo)" on journal_entries for insert with check (true);
create policy "Authors can update own" on journal_entries for update using (auth.uid() = author_id);

-- ─────────────────────────────────────────────
-- EMAILS
-- ─────────────────────────────────────────────
create table if not exists subscribers (
  id uuid primary key default uuid_generate_v4(),
  email text unique not null,
  display_name text,
  source text default 'site',
  created_at timestamp with time zone default now()
);
alter table subscribers enable row level security;
create policy "Anyone can subscribe (demo)" on subscribers for insert with check (true);
create policy "Service can read subscribers" on subscribers for select using (true);

-- ─────────────────────────────────────────────
-- PUZZLE PURCHASES (webhook from Stripe)
-- ─────────────────────────────────────────────
create table if not exists purchases (
  id uuid primary key default uuid_generate_v4(),
  email text not null,
  stripe_session_id text unique,
  stripe_price_id text,
  product_name text,
  amount_cents int,
  created_at timestamp with time zone default now()
);
alter table purchases enable row level security;
create policy "Anyone can insert via webhook (demo)" on purchases for insert with check (true);

-- ─────────────────────────────────────────────
-- LIVE STATE (single row, controlled by creator)
-- ─────────────────────────────────────────────
create table if not exists live_state (
  id int primary key default 1 check (id = 1),
  is_live boolean default false,
  current_puzzle text,
  current_prompt text,
  current_poll jsonb,
  timer_text text,
  updated_at timestamp with time zone default now()
);
insert into live_state (id, is_live) values (1, false) on conflict (id) do nothing;

-- REQUIRED: live_state must be in the realtime publication, otherwise admin
-- LIVE toggles / puzzle pushes / prompts / timers / polls never reach viewers
-- until they reload. (This statement is safe to re-run.)
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and tablename = 'live_state'
  ) then
    alter publication supabase_realtime add table live_state;
  end if;
end $$;
alter table live_state enable row level security;
create policy "Anyone can read live_state" on live_state for select using (true);
create policy "Anyone can update live_state (demo)" on live_state for update using (true);
-- In production: restrict update to your user id only:

-- ═════════════════════════════════════════════
-- MODERATION — NEW
-- ═════════════════════════════════════════════

-- Moderators: who can moderate (you add them in portals)
create table if not exists moderators (
  id uuid primary key default uuid_generate_v4(),
  email text unique not null,
  display_name text not null,
  role text not null check (role in ('owner','lead','moderator')), -- owner = you, lead = trusted, moderator = community
  is_active boolean default true,
  added_by text, -- who added them
  notes text,
  created_at timestamp with time zone default now()
);
alter table moderators enable row level security;
create policy "Anyone can read moderators" on moderators for select using (true);
create policy "Anyone can insert moderators (demo)" on moderators for insert with check (true);
create policy "Anyone can update moderators (demo)" on moderators for update with check (true);
-- In production: only owner can insert/update

-- Seed owner (replace with your real email after)
insert into moderators (email, display_name, role, notes) values
  ('owner@safesplayce.com', 'Safesplayce Owner', 'owner', 'Replace email with your real owner email')
on conflict (email) do nothing;

-- Reports: when someone clicks 🚩 report
create table if not exists reports (
  id uuid primary key default uuid_generate_v4(),
  room_id uuid references rooms(id) on delete set null,
  message_id uuid references messages(id) on delete cascade,
  reporter_name text not null,
  reported_display_name text not null,
  message_body text not null,
  reason text not null check (reason in ('harassment','medical_advice','self_harm','spam','hate','privacy','other')),
  details text,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  reviewed_by text,
  action_taken text,
  created_at timestamp with time zone default now()
);
alter table reports enable row level security;
create policy "Anyone can create reports" on reports for insert with check (true);
create policy "Anyone can read reports (demo)" on reports for select using (true);
create policy "Anyone can update reports (demo)" on reports for update with check (true);
alter publication supabase_realtime add table reports;

-- Mutes / Timeouts / Bans
create table if not exists mutes (
  id uuid primary key default uuid_generate_v4(),
  display_name text not null, -- muted user display name (we don't store IPs; for demo we use name)
  room_id uuid references rooms(id) on delete set null, -- null = global
  reason text,
  expires_at timestamp with time zone, -- null = permanent
  is_ban boolean default false,
  created_by text not null, -- moderator display name
  created_at timestamp with time zone default now()
);
alter table mutes enable row level security;
create policy "Anyone can read mutes" on mutes for select using (true);
create policy "Anyone can insert mutes (demo)" on mutes for insert with check (true);
create policy "Anyone can delete mutes (demo)" on mutes for delete using (true);
alter publication supabase_realtime add table mutes;

-- Audit log: every mod action is logged (accountability)
create table if not exists audit_log (
  id uuid primary key default uuid_generate_v4(),
  actor_name text not null,
  actor_role text,
  action text not null, -- e.g. 'hide_message', 'mute_user', 'resolve_report'
  target text, -- e.g. display_name or message_id
  details text,
  room_id uuid references rooms(id) on delete set null,
  created_at timestamp with time zone default now()
);
alter table audit_log enable row level security;
create policy "Anyone can read audit (demo)" on audit_log for select using (true);
create policy "Anyone can insert audit (demo)" on audit_log for insert with check (true);
alter publication supabase_realtime add table audit_log;

-- System messages: moderators can broadcast to a room
create table if not exists system_messages (
  id uuid primary key default uuid_generate_v4(),
  room_id uuid references rooms(id) on delete cascade not null,
  body text not null,
  created_by text not null,
  created_at timestamp with time zone default now()
);
alter table system_messages enable row level security;
create policy "Anyone can read system messages" on system_messages for select using (true);
create policy "Anyone can insert system messages (demo)" on system_messages for insert with check (true);
alter publication supabase_realtime add table system_messages;

-- Indexes
create index if not exists idx_messages_room on messages(room_id, created_at);
create index if not exists idx_journal_privacy on journal_entries(privacy, created_at desc);
create index if not exists idx_reports_status on reports(status, created_at desc);
create index if not exists idx_mutes_name on mutes(display_name, expires_at);
create index if not exists idx_audit_created on audit_log(created_at desc);
