// ═══════════════════════════════════════════════════════════════════════
// Safesplayce — Creator Control bridge (/admin)
// LIVE toggle, puzzle push, prompt push, timer push and poll push now go
// to the Netlify API so every visitor sees them on their device.
// ═══════════════════════════════════════════════════════════════════════
(function () {
  const API = "/api";
  const $ = (id) => document.getElementById(id);
  const CFG = window.SAFESPLAYCE_CONFIG || {};

  function modCode() {
    return sessionStorage.getItem("sp_mod_code") || (CFG.moderation && CFG.moderation.demoCode) || "SAFE2026";
  }

  let writesPending = 0; // guards against stale poll responses clobbering fresh writes

  async function api(path, body) {
    if (body) writesPending++;
    const r = await fetch(API + path, {
      method: body ? "POST" : "GET",
      headers: { "content-type": "application/json", "x-mod-code": modCode() },
      body: body ? JSON.stringify(body) : undefined,
    }).finally(() => {
      if (body) writesPending--;
    });
    if (r.status === 401 && body) {
      const code = prompt("Creator code was rejected.\nEnter the creator/moderator code from your Netlify settings (SAFESPLAYCE_MOD_CODE):");
      if (code) {
        sessionStorage.setItem("sp_mod_code", code.trim());
        return api(path, body); // retry once
      }
    }
    return r.json();
  }

  let connected = false;

  function setStatus(text, ok) {
    const el = $("supaStatus");
    if (!el) return;
    el.textContent = text;
    el.style.color = ok ? "#3F8F5F" : "#9A7B2E";
  }

  // ── Reflect server state in the admin UI ──
  function renderLiveBanner(on) {
    // The page's own isLive is a lexical `let` we can't touch — update the DOM directly.
    const banner = $("liveBanner"), sw = $("liveSwitch"), txt = $("liveText"), sub = $("liveSub");
    if (on) {
      if (banner) banner.className = "live-banner on";
      if (sw) sw.classList.add("on");
      if (txt) txt.textContent = "🔴 LIVE NOW";
      if (sub) sub.textContent = "TikTok + Safesplayce are live — viewers see LIVE banner";
    } else {
      if (banner) banner.className = "live-banner off";
      if (sw) sw.classList.remove("on");
      if (txt) txt.textContent = "OFFLINE";
      if (sub) sub.textContent = "TikTok + Safesplayce are offline";
    }
  }

  function reflect(live) {
    if (!live) return;
    try {
      window.isLive = !!live.is_live;
      renderLiveBanner(window.isLive);
      if (live.current_puzzle) {
        const cg = $("currentGame");
        if (cg) cg.textContent = live.current_puzzle;
      }
      if (live.current_prompt) {
        const vp = $("viewerPrompt");
        if (vp) vp.textContent = live.current_prompt;
      }
      if (live.current_poll) {
        const p = live.current_poll;
        if ($("pollQ")) $("pollQ").value = p.q || "";
        if ($("pollA")) $("pollA").value = p.a || "";
        if ($("pollB")) $("pollB").value = p.b || "";
        if ($("pollC")) $("pollC").value = p.c || "";
        const votes = p.votes || {};
        const total = Object.values(votes).reduce((a, b) => a + b, 0);
        const pr = $("pollResult");
        if (pr) {
          pr.textContent = total
            ? "Live votes: " + [p.a, p.b, p.c].filter(Boolean).map((o) => o + " — " + (votes[o] || 0)).join(" • ") + "  (total " + total + ")"
            : "Poll is live — waiting for votes…";
        }
      }
      if (live.timer_text) {
        const td = $("timerDisplay");
        if (td && typeof window._spAdminTimerRunning === "undefined") td.textContent = live.timer_text;
      }
    } catch (e) {}
  }

  async function pollServer() {
    try {
      const r = await fetch(API + "/live");
      const j = await r.json();
      if (j && j.ok) {
        if (!connected) {
          connected = true;
          setStatus("✅ Connected to site (Netlify)", true);
        }
        // Don't apply a poll result that was in flight while we were writing —
        // it can be stale and flip the LIVE switch back.
        if (writesPending === 0) reflect(j.live);
      }
    } catch (e) {
      connected = false;
      setStatus("⚠️ Site API unreachable — controls are local only", false);
    }
  }

  // ── Wrap creator controls to push to the server ──
  function install() {
    const prevToggle = window.toggleLive;
    window.toggleLive = async function () {
      const willBeLive = !window.isLive;
      const res = await api("/live", { is_live: willBeLive });
      if (!res || !res.ok) {
        alert("Could not update LIVE state: " + ((res && res.error) || "network"));
        return;
      }
      window.isLive = !!res.live.is_live;
      renderLiveBanner(window.isLive);
      if (window.isLive) await window.pushGame("🔴 LIVE — Welcome! Tonight’s puzzle drops in a moment");
    };

    const prevPushGame = window.pushGame;
    window.pushGame = async function (title) {
      const full = title + " • " + new Date().toLocaleTimeString();
      const cg = $("currentGame"), cgt = $("currentGameTime");
      if (cg) cg.textContent = title;
      if (cgt) cgt.textContent = "Pushed at " + new Date().toLocaleTimeString();
      await api("/live", { current_puzzle: full });
    };

    const prevClear = window.clearGame;
    window.clearGame = async function () {
      const cg = $("currentGame");
      if (cg) cg.textContent = "Cleared — waiting…";
      await api("/live", { current_puzzle: "Waiting for creator to push a puzzle…" });
    };

    const prevPrompt = window.pushScriptToSiteWith;
    window.pushScriptToSiteWith = async function (txt) {
      const promptText = String(txt || "").split("\n").filter(Boolean)[0].slice(0, 120);
      const vp = $("viewerPrompt");
      if (vp) vp.textContent = promptText;
      const res = await api("/live", { current_prompt: promptText });
      if (res && res.ok) alert('Prompt pushed to site: “' + promptText + '”');
      else alert("Push failed — is the API running?");
    };

    const prevTimer = window.pushTimer;
    window.pushTimer = async function () {
      const t = $("timerDisplay") ? $("timerDisplay").textContent : "";
      const res = await api("/live", { timer_text: t });
      if (res && res.ok) alert("Timer pushed to site: " + t);
      else alert("Push failed — is the API running?");
    };

    const prevPoll = window.pushPoll;
    window.pushPoll = async function () {
      const q = $("pollQ").value.trim(), a = $("pollA").value.trim(), b = $("pollB").value.trim(), c = $("pollC").value.trim();
      if (!q || !a || !b) {
        alert("Add question + at least 2 options");
        return;
      }
      const res = await api("/live", { current_poll: { q, a, b, c } });
      const pr = $("pollResult");
      if (res && res.ok) {
        if (pr) pr.textContent = 'Pushed: “' + q + '” — live votes will appear here.';
      } else if (pr) {
        pr.textContent = "Push failed — is the API running?";
      }
    };
  }

  (async function boot() {
    try {
      const h = await fetch(API + "/health").then((r) => r.json());
      if (h && h.ok) {
        connected = true;
        setStatus("✅ Connected to site (Netlify)", true);
        install();
        await pollServer();
        setInterval(pollServer, 5000);
      } else {
        setStatus("⚠️ Demo mode — deploy to Netlify for site-wide controls", false);
      }
    } catch (e) {
      setStatus("⚠️ Demo mode — deploy to Netlify for site-wide controls", false);
    }
  })();
})();
