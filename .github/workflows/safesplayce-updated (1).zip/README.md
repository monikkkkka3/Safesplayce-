# Safesplayce — Separate Moderator & Creator Logins

Updated site with **two separate, private logins** and **no creator access visible on the public side**.

## 🔐 The two logins

| Who | Where | How it works |
|---|---|---|
| **Creator (you)** | `/admin` — bookmark it; **never linked** from the public site | Email + creator passcode. Session stored under `safesplayce_creator_session`. |
| **Moderators** | `/moderators` — linked as “🛡️ Mod Sign In” | Email + display name + mod access code. Session stored under separate keys (`safesplayce_moderator`, `safesplayce_is_mod`, …). |

The sessions are fully independent:
- A moderator sign-in **never** unlocks Creator Control.
- If a moderator opens `/admin`, they see a notice that creator controls require the **owner passcode**.
- Signing out of one does not affect the other.

## 🔑 Demo credentials (CHANGE THESE!)

In `config.js`:

```js
owner: {
  emails: [],          // optional: lock creator login to these emails
  demoCode: "OWNER2026" // ← creator passcode — change before going live
},
moderation: {
  demoCode: "SAFE2026"  // ← moderator code — rotate monthly
}
```

- **Creator sign-in:** any email (or one in `owner.emails`) + passcode `OWNER2026`
- **Moderator sign-in:** any email + name + code `SAFE2026`

## 🚀 Deploy to Netlify

1. Zip this `safesplayce` folder (or drag it as-is).
2. Netlify → your site → **Deploys → Drag & drop your site output folder here** (replaces the current deploy), or **Add new site → Deploy manually**.
3. URLs: `/` (public), `/moderators` (mod login), `/admin` (creator login — keep this to yourself).

Folder-based pages (`admin/index.html`, `moderators/index.html`) serve cleanly at `/admin` and `/moderators` with no redirects needed.

## ⚠️ Security note

This is a static demo site, so the gate is **client-side** (same approach the site already used for demo mode — it keeps curious visitors out, not a determined attacker). For real protection, connect Supabase:

1. Put your `supabaseUrl` + `supabaseAnonKey` in `config.js`.
2. Run `supabase-schema.sql` in the Supabase SQL editor.
3. Add yourself to the `moderators` table with `role = 'owner'` — you can then sign in at `/admin` with your email, and moderator accounts are validated against the table.

## 📝 What changed vs. the live site

- ❌ Removed the “🎛️ Creator Control” button from the public header
- ❌ Removed the “🎮 Live Controls (For Creator)” card from the Live Schedule section (replaced with a moderator-only info card)
- ❌ Removed the “Creator Control App” link from the footer
- ❌ Removed the “Creator Control” button from the moderator portal header
- ✅ Added a creator login gate on `/admin` (sign-in view, session restore, sign-out, mod-session notice)
- ✅ Added `owner` config block in `config.js`
- ✅ Kept the moderator portal at `/moderators` as the separate mod login
