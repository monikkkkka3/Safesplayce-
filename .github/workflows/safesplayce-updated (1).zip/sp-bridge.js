// ═══════════════════════════════════════════════════════════════════════
// Safesplayce — Netlify API bridge (main site)
// When /api is reachable, chat rooms, journals, live state, polls and
// reports run on the shared server (real multi-user). Otherwise the site
// keeps working in localStorage demo mode — nothing breaks.
// ═══════════════════════════════════════════════════════════════════════
(function () {
  const API = "/api";
  const $ = (id) => document.getElementById(id);
  const esc = (s) =>
    String(s == null ? "" : s).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  const myName = () => localStorage.getItem("safesplayce_display") || "Gentle Guest";

  async function api(path, opts) {
    const r = await fetch(API + path, Object.assign({ headers: { "content-type": "application/json" } }, opts || {}));
    return r.json();
  }

  let apiOK = false;

  // ── Safe re-renders (original renderers inject raw HTML; escape server data) ──
  const prevRenderRooms = window.renderRooms;
  window.renderRooms = function () {
    if (!apiOK) return prevRenderRooms && prevRenderRooms();
    const el = $("roomList");
    if (!el) return;
    el.innerHTML = "";
    window.rooms.forEach((r) => {
      const isPrivate = !!r.code;
      const div = document.createElement("div");
      div.className = "room";
      div.innerHTML = `
        <div>
          <div style="display:flex;align-items:center;gap:.5rem"><strong>${esc(r.name)}</strong> ${isPrivate ? '<span class="tag tag-peach" style="font-size:.65rem">Private</span>' : '<span class="tag tag-sage" style="font-size:.65rem">Open</span>'} <small>• ${Number(r.members) || 1} here</small></div>
          <small>${esc(r.topic || "")} ${isPrivate ? `• code: ${esc(r.code)}` : ""}</small>
        </div>
        <div class="room-actions">
          <button class="btn btn-primary" style="padding:.45rem .8rem;font-size:.8rem" onclick="joinRoom('${String(r.id).replace(/[^a-zA-Z0-9_]/g, "")}')">Join</button>
        </div>`;
      el.appendChild(div);
    });
  };

  const prevRenderJournal = window.renderJournal;
  window.renderJournal = function () {
    if (!apiOK) return prevRenderJournal && prevRenderJournal();
    const feed = $("journalFeed");
    if (!feed) return;
    feed.innerHTML = "";
    const filtered = window.journalEntries.filter(
      (e) => typeof journalFilter === "undefined" || journalFilter === "all" || e.privacy === journalFilter
    );
    if (filtered.length === 0) {
      feed.innerHTML = '<div class="entry" style="text-align:center;color:var(--muted)">No entries yet — write your first gentle note.</div>';
      return;
    }
    filtered.forEach((e) => {
      const div = document.createElement("div");
      div.className = "entry " + (e.privacy === "private" ? "private" : "public");
      div.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.4rem">
          <strong style="font-size:.95rem">${esc(e.title)}</strong>
          <span class="tag ${e.privacy === "private" ? "tag-peach" : "tag-sage"}" style="font-size:.65rem">${e.privacy === "private" ? "🔒 Private" : "🌿 Public"}</span>
        </div>
        <div style="font-size:.9rem;white-space:pre-wrap">${esc(e.body)}</div>
        <div style="font-size:.75rem;color:var(--muted);margin-top:.5rem;display:flex;justify-content:space-between"><span>${esc(e.author)}</span><span>${esc(e.time)}</span></div>`;
      feed.appendChild(div);
    });
  };

  // ── State application ──
  function applyRooms(rooms) {
    if (!Array.isArray(rooms) || !rooms.length) return;
    window.rooms = rooms.map((r) => ({
      id: r.id,
      name: r.name,
      code: r.code || "",
      members: r.members || 1,
      topic: r.topic || "",
    }));
    window.renderRooms();
  }

  function applyMessages(list) {
    const id = window.currentRoomId;
    if (!id) return;
    const my = localStorage.getItem("safesplayce_display") || "";
    const mapped = list.map((m) => ({
      who: m.display_name === my ? "you" : "them",
      name: m.display_name,
      text: m.body,
      time: new Date(m.created_at).toLocaleTimeString(),
      hidden: !!m.hidden,
      isSystem: !!m.system,
      id: m.id,
    }));
    if (mapped.length === 0) {
      mapped.push({
        who: "them",
        name: "Safesplayce Host",
        text: "Welcome in — I’m so glad you’re here. No need to share more than you want. One breath at a time. 💛",
        time: new Date().toLocaleTimeString(),
      });
    }
    const sig = mapped.map((m) => (m.id || m.name) + ":" + (m.hidden ? "h" : "v")).join("|");
    if (window._spMsgSig === sig) return;
    window._spMsgSig = sig;
    window.messagesByRoom[id] = mapped;
    if (typeof renderMessages === "function") renderMessages();
  }

  function renderPoll(poll) {
    if (!poll) return;
    const box = $("pollDisplay"), q = $("pollQDisplay"), opts = $("pollOptions");
    if (!box || !q || !opts) return;
    q.textContent = poll.q || "";
    opts.innerHTML = "";
    const votes = poll.votes || {};
    const total = Object.values(votes).reduce((a, b) => a + b, 0);
    const votedKey = "sp_voted_" + (poll.q || "");
    const alreadyVoted = sessionStorage.getItem(votedKey);
    [poll.a, poll.b, poll.c].filter(Boolean).forEach((opt) => {
      const count = votes[opt] || 0;
      const btn = document.createElement("button");
      btn.className = "btn btn-ghost";
      btn.style.cssText = "padding:.5rem .7rem;font-size:.85rem;text-align:left;display:flex;justify-content:space-between;gap:1rem;width:100%";
      btn.innerHTML = "<span>" + esc(opt) + "</span><strong>" + count + (total ? " (" + Math.round((count * 100) / total) + "%)" : "") + "</strong>";
      if (alreadyVoted) {
        btn.disabled = true;
        btn.style.opacity = alreadyVoted === opt ? "1" : ".5";
        if (alreadyVoted === opt) btn.style.background = "#7B6BA0";
      }
      btn.onclick = async () => {
        await api("/vote", { method: "POST", body: JSON.stringify({ option: opt }) });
        sessionStorage.setItem(votedKey, opt);
        sync();
      };
      opts.appendChild(btn);
    });
    if (alreadyVoted) {
      const note = document.createElement("div");
      note.style.cssText = "font-size:.72rem;color:var(--muted);margin-top:.4rem";
      note.textContent = "Thanks for voting 💜";
      opts.appendChild(note);
    }
    box.style.display = "block";
  }

  function applyLive(live) {
    if (!live) return;
    window.isLive = !!live.is_live;
    if (typeof renderLive === "function") renderLive();
    const puzzleEl = $("livePuzzleDisplay");
    if (live.current_puzzle && puzzleEl) {
      puzzleEl.textContent = live.current_puzzle;
      const meta = $("livePuzzleMeta");
      if (meta) meta.textContent = "Pushed by creator at " + new Date(live.updated_at).toLocaleTimeString();
    }
    if (live.current_prompt) {
      const box = $("viewerPromptDisplay"), txt = $("viewerPromptText");
      if (box && txt) {
        txt.textContent = live.current_prompt;
        box.style.display = "block";
      }
    }
    if (live.current_poll) renderPoll(live.current_poll);
    if (live.timer_text) {
      const box = $("timerLiveDisplay"), txt = $("timerLiveText");
      if (box && txt) {
        txt.textContent = live.timer_text;
        box.style.display = "block";
      }
    }
  }

  function applyJournals(pub) {
    if (!Array.isArray(pub)) return;
    const priv = (window.journalEntries || []).filter((j) => j.privacy === "private");
    const pubMapped = pub.map((d) => ({
      id: d.id,
      title: d.title,
      body: d.body,
      privacy: "public",
      author: d.display_name,
      time: new Date(d.created_at).toLocaleDateString(),
    }));
    window.journalEntries = [...priv, ...pubMapped];
    if (typeof renderJournal === "function") renderJournal();
  }

  async function sync() {
    if (!apiOK) return;
    try {
      const room = window.currentRoomId ? "?room=" + encodeURIComponent(window.currentRoomId) : "";
      const s = await api("/state" + room);
      if (!s || !s.ok) return;
      applyLive(s.live);
      applyRooms(s.rooms);
      applyJournals(s.publicJournals);
      if (window.currentRoomId && Array.isArray(s.messages)) applyMessages(s.messages);
    } catch (e) {
      /* network hiccup — try again next tick */
    }
  }

  // ── Wrap the demo functions with API-backed versions ──
  function installWrappers() {
    const prevJoin = window.joinRoom;
    window.joinRoom = async function (id, skipCode) {
      if (!apiOK) return prevJoin && prevJoin(id);
      const r = window.rooms.find((x) => x.id === id);
      if (!r) return;
      if (r.code && !skipCode) {
        const tryCode = prompt('Enter code for "' + r.name + '"');
        if (!tryCode || tryCode.toUpperCase() !== String(r.code).toUpperCase()) {
          alert("That code didn’t match.");
          return;
        }
      }
      if (!localStorage.getItem("safesplayce_display")) {
        const dn = prompt("Choose a display name for chat (only this is shown):", "Gentle Guest");
        if (!dn) return;
        localStorage.setItem("safesplayce_display", dn.trim());
        window.displayName = dn.trim();
      }
      window.currentRoomId = id;
      window._spMsgSig = "";
      $("chatTitle").textContent = r.name;
      $("chatSubtitle").textContent = r.code ? "Private • code " + r.code : "Open room • Be kind";
      $("chatStatus").textContent = "Joined • live";
      window.messagesByRoom[id] = [];
      if (typeof renderMessages === "function") renderMessages();
      sync();
    };

    const prevSend = window.sendMessage;
    window.sendMessage = async function () {
      if (!apiOK) return prevSend && prevSend();
      const input = $("chatInput");
      const text = input.value.trim();
      if (!text) return;
      if (!window.currentRoomId) {
        alert("Join a room first");
        return;
      }
      const name = myName();
      input.value = "";
      // optimistic echo
      const list = window.messagesByRoom[window.currentRoomId] || [];
      list.push({ who: "you", name, text, time: new Date().toLocaleTimeString(), pending: true });
      window.messagesByRoom[window.currentRoomId] = list;
      if (typeof renderMessages === "function") renderMessages();
      const res = await api("/messages", { method: "POST", body: JSON.stringify({ room_id: window.currentRoomId, display_name: name, text }) });
      if (res && res.ok) {
        sync();
      } else {
        input.value = text;
        const msg = res && res.error === "slow_down" ? "Gently now — one message at a time 🌿" : (res && res.error) || "Message didn’t send — try again";
        if (typeof showToast === "function") showToast(msg);
      }
    };

    const prevCreate = window.createRoom;
    window.createRoom = async function () {
      if (!apiOK) return prevCreate && prevCreate();
      const name = $("newRoomName").value.trim();
      const code = $("newRoomCode").value.trim();
      const dName = $("newRoomNameDisplay").value.trim();
      if (!name) {
        alert("Give your room a cozy name");
        return;
      }
      if (dName) {
        localStorage.setItem("safesplayce_display", dName);
        window.displayName = dName;
      }
      const res = await api("/rooms", { method: "POST", body: JSON.stringify({ name, code, topic: "Private room • kind only" }) });
      if (!res || !res.ok) {
        alert((res && res.error) || "Could not create room");
        return;
      }
      $("newRoomName").value = "";
      $("newRoomCode").value = "";
      $("newRoomNameDisplay").value = "";
      const overlay = $("roomOverlay");
      if (overlay) overlay.classList.remove("open");
      await sync();
      window.joinRoom(res.room.id, true); // creator auto-joins without re-entering their own code
    };

    const prevSaveJournal = window.saveJournal;
    window.saveJournal = async function () {
      const priv = typeof window.privacy !== "undefined" ? window.privacy : "private";
      if (!apiOK || priv === "private") return prevSaveJournal && prevSaveJournal(); // private stays on this device only
      const title = $("journalTitle").value.trim();
      const body = $("journalBody").value.trim();
      if (!body) {
        alert("Write a little first — even one line counts.");
        return;
      }
      const name = myName();
      const res = await api("/journal", { method: "POST", body: JSON.stringify({ title, body, display_name: name }) });
      if (res && res.ok) {
        $("journalTitle").value = "";
        $("journalBody").value = "";
        if (typeof showToast === "function") showToast("Shared gently 🌿");
        sync();
      } else {
        prevSaveJournal && prevSaveJournal();
      }
    };

    const prevReport = window.submitReport;
    window.submitReport = async function () {
      if (!apiOK) return prevReport && prevReport();
      const reason = $("reportReason").value;
      const details = $("reportDetails").value.trim();
      const roomId = $("reportRoomId").value;
      const name = $("reportTargetName").textContent;
      const body = $("reportTargetBody").textContent;
      if (!name || !body) {
        alert("Nothing to report");
        return;
      }
      const reporter = myName();
      const res = await api("/report", {
        method: "POST",
        body: JSON.stringify({ name, body, room_id: roomId, reason, details, reporter }),
      });
      if (res && res.ok) {
        if (typeof closeReport === "function") closeReport();
        if (typeof showToast === "function") {
          showToast(
            reason === "self_harm"
              ? "Thank you — moderators notified. If you can, let the person know: call/text 988, text HOME to 741741."
              : "Report sent — thank you for keeping this place kind. 💛"
          );
        }
        sync();
      } else if (typeof showToast === "function") showToast("Report failed — please try again");
    };

    const prevSubscribe = window.subscribe;
    window.subscribe = async function (e) {
      if (e && e.preventDefault) e.preventDefault();
      if (!apiOK) return prevSubscribe && prevSubscribe(e);
      const email = $("subEmail").value.trim();
      const name = $("subName").value.trim();
      if (!email || !name) return;
      const res = await api("/subscribe", { method: "POST", body: JSON.stringify({ email }) });
      if (res && res.ok) {
        localStorage.setItem("safesplayce_display", name);
        window.displayName = name;
        localStorage.setItem("safesplayce_subscribed", "1");
        const ok = $("subSuccess");
        if (ok) {
          ok.style.display = "block";
          setTimeout(() => (ok.style.display = "none"), 4000);
        }
        if (e && e.target && e.target.reset) e.target.reset();
      } else if (typeof showToast === "function") {
        showToast((res && res.error) || "Could not subscribe — try again");
      }
    };

    // LIVE is controlled from /admin now
    const prevToggle = window.toggleDemoLive;
    window.toggleDemoLive = function () {
      if (!apiOK) return prevToggle && prevToggle();
      if (typeof showToast === "function") showToast("LIVE is controlled from the Creator Control app (/admin) 🎛️");
    };
  }

  // ── Boot ──
  (async function boot() {
    try {
      const h = await api("/health");
      if (!h || !h.ok) return;
      apiOK = true;
      window.SP_API = true;
      const banner = $("setupBanner");
      if (banner) banner.style.display = "none";
      const st = $("chatStatus");
      if (st) st.textContent = "Connected";
      installWrappers();
      await sync();
      setInterval(sync, 3500);
      console.log("Safesplayce: connected to Netlify API (" + h.store + " storage)");
    } catch (e) {
      console.log("Safesplayce: API not reachable — staying in demo mode");
    }
  })();
})();
