// ═══════════════════════════════════════════════════════════════════════
// Safesplayce — Moderation bridge (/moderators.html)
// Reports, rooms, mutes, journals and audit now come from the shared
// server, so every moderator sees the same queue from any device.
// ═══════════════════════════════════════════════════════════════════════
(function () {
  const API = "/api";

  function modCode() {
    return sessionStorage.getItem("sp_mod_code") || "SAFE2026";
  }
  const byName = () => (JSON.parse(localStorage.getItem("safesplayce_moderator") || "null") || {}).display_name || "Moderator";

  async function apiGet(path) {
    const r = await fetch(API + path, { headers: { "x-mod-code": modCode() } });
    return r.json();
  }
  async function apiPost(path, body) {
    let r = await fetch(API + path, {
      method: "POST",
      headers: { "content-type": "application/json", "x-mod-code": modCode() },
      body: JSON.stringify(body),
    });
    if (r.status === 401) {
      const code = prompt("Creator/moderator code rejected. Enter the code (SAFESPLAYCE_MOD_CODE):");
      if (code) {
        sessionStorage.setItem("sp_mod_code", code.trim());
        r = await fetch(API + path, {
          method: "POST",
          headers: { "content-type": "application/json", "x-mod-code": modCode() },
          body: JSON.stringify(body),
        });
      }
    }
    return r.json();
  }

  let connected = false;

  function install() {
    // Capture the code typed at login
    const prevLogin = window.login;
    window.login = async function () {
      const code = (document.getElementById("loginCode") || {}).value || "";
      await prevLogin();
      if (localStorage.getItem("safesplayce_moderator")) sessionStorage.setItem("sp_mod_code", code.trim() || modCode());
    };

    // ── Loaders: pull from server ──
    window.loadReports = async function () {
      const d = await apiGet("/mod");
      if (d && d.ok) {
        reportsCache = d.reports || [];
        connected = true;
      } else {
        reportsCache = JSON.parse(localStorage.getItem("safesplayce_reports") || "[]");
      }
    };
    window.loadRooms = async function () {
      const d = await apiGet("/mod");
      if (d && d.ok) roomsCache = (d.rooms || []).filter((r) => !r.closed);
      else roomsCache = JSON.parse(localStorage.getItem("safesplayce_rooms") || "[]");
    };
    window.loadJournals = async function () {
      const d = await apiGet("/mod");
      if (d && d.ok) {
        journalsCache = (d.journals || []).map((j) => ({
          id: j.id,
          title: j.title,
          body: j.body,
          privacy: j.privacy || "public",
          author: j.display_name,
          time: new Date(j.created_at).toLocaleString(),
          flagged: false,
        }));
      } else {
        journalsCache = JSON.parse(localStorage.getItem("safesplayce_journal") || "[]");
      }
    };
    window.loadMutes = async function () {
      const d = await apiGet("/mod");
      if (d && d.ok) {
        const mutes = (d.mutes || []).map((m) => ({
          id: m.id,
          display_name: m.display_name,
          room_id: m.room_id || null,
          reason: m.reason,
          expires_at: m.expires_at || null,
          is_ban: !m.expires_at,
          created_by: m.by || "Moderator",
          created_at: m.created_at || new Date().toISOString(),
        }));
        localStorage.setItem("safesplayce_mutes", JSON.stringify(mutes));
      }
    };
    window.loadAudit = async function () {
      const d = await apiGet("/mod");
      if (d && d.ok) {
        const audits = (d.audit || []).map((a) => ({ ...a, actor_role: a.actor_role || "mod" }));
        localStorage.setItem("safesplayce_audit", JSON.stringify(audits.slice(0, 200)));
      }
    };

    // ── Actions: write to server ──
    window.updateReport = async function (id, status) {
      const note = prompt(`Add a note for this ${status} action (optional):`) || "";
      const res = await apiPost("/mod/action", { action: "resolve", id, status, note, by: byName() });
      if (!res || !res.ok) alert("Action failed: " + ((res && res.error) || "network"));
      await refreshAll();
    };

    window.hideMessageFromReport = async function (reportId) {
      const r = reportsCache.find((x) => x.id === reportId);
      if (!r) return;
      const reason = prompt("Reason for hiding (shown in audit):", "Hide per report — " + r.reason) || "";
      const res = await apiPost("/mod/action", {
        action: "hide",
        report_id: reportId,
        reported_display_name: r.reported_display_name,
        message_body: r.message_body,
        reason,
        by: byName(),
      });
      if (res && res.ok) alert(res.hidden ? "Message hidden for all viewers." : "Report resolved (exact message not found).");
      else alert("Action failed: " + ((res && res.error) || "network"));
      await refreshAll();
    };

    window.createMuteFor = async function (name, roomId, minutesOrPerm, reason) {
      const isPerm = minutesOrPerm === "permanent";
      const res = await apiPost("/mod/action", {
        action: "mute",
        display_name: name,
        minutes: isPerm ? "permanent" : parseInt(minutesOrPerm, 10) || 60,
        room_id: roomId || null,
        reason,
        by: byName(),
      });
      if (!res || !res.ok) alert("Mute failed: " + ((res && res.error) || "network"));
      else alert((isPerm ? "Banned " : "Muted ") + name + (isPerm ? " permanently" : " for " + minutesOrPerm + "m"));
      await refreshAll();
    };

    window.unmute = async function (id) {
      await apiPost("/mod/action", { action: "unmute", id, by: byName() });
      await refreshAll();
    };

    window.closeRoom = async function (id) {
      if (!confirm("Close this room? It will be hidden for new joins, but history remains.")) return;
      const res = await apiPost("/mod/action", { action: "closeRoom", id, by: byName() });
      if (!res || !res.ok) alert("Close failed: " + ((res && res.error) || "network"));
      await refreshAll();
    };

    window.sendSystemMessage = async function () {
      const roomId = document.getElementById("broadcastRoom").value;
      const body = document.getElementById("broadcastBody").value.trim();
      if (!roomId || !body) {
        alert("Pick a room and write a message");
        return;
      }
      const res = await apiPost("/mod/action", { action: "broadcast", room_id: roomId, text: body, by: byName() });
      if (res && res.ok) {
        alert("System message sent to room!");
        document.getElementById("broadcastBody").value = "";
      } else {
        alert("Send failed: " + ((res && res.error) || "network"));
      }
      await refreshAll();
    };
  }

  (async function boot() {
    try {
      const h = await fetch(API + "/health").then((r) => r.json());
      if (h && h.ok) {
        connected = true;
        install();
        // If already logged in, refresh from server now + periodically
        if (localStorage.getItem("safesplayce_moderator")) {
          setTimeout(() => window.refreshAll && window.refreshAll(), 300);
          setInterval(() => {
            if (document.getElementById("dashView") && document.getElementById("dashView").style.display !== "none") {
              window.refreshAll && window.refreshAll();
            }
          }, 10000);
        }
        console.log("Safesplayce moderation: connected to Netlify API");
      } else {
        console.log("Safesplayce moderation: demo mode (no API)");
      }
    } catch (e) {
      console.log("Safesplayce moderation: demo mode (no API)");
    }
  })();
})();
