// Safesplayce — Central Config
// Replace placeholder values with your real keys when ready.
// Demo mode works with no keys — you can preview everything right now.
window.SAFESPLAYCE_CONFIG = {
  // ── Site ──
  siteUrl: "https://safesplayce.link",
  siteDomain: "safesplayce.link",

  // ── TikTok ──
  // Change these to your real handle and we update every button/link automatically
  tiktokHandle: "safesplayce",
  tiktokLiveUrl: "https://www.tiktok.com/@safesplayce/live",
  tiktokProfileUrl: "https://www.tiktok.com/@safesplayce",
  // If you use TikTok Live Studio, paste your Live Studio deep link here (optional)
  tiktokLiveStudioUrl: "",

  // ── Theme / Wording ──
  // Quick rebrand without touching HTML — change colors & copy here
  theme: {
    // Palette: warm, low-stimulation, WCAG AA contrast
    cream: "#FFFBF7",
    warm: "#FFF1E6",
    sage: "#D8E8D5",
    sageDeep: "#7FAE7B",
    teal: "#6BA8A9",
    tealDeep: "#2F5D5E",
    tealLight: "#E6F2F2",
    lav: "#EDE7F6",
    lavDeep: "#7B6BA0",
    peach: "#FFDAB9",
    peachDeep: "#E8A87C"
  },
  copy: {
    heroTitle: "A soft place to land when your mind feels loud.",
    heroSubtitle: "Hey, it's me — your TikTok friend. Safesplayce is our private, cozy corner off TikTok where we meet in small peer-support rooms, quiet our minds with puzzles, and journal privately or share if you want. No pressure. Just gentle support, made with care in Dallas, TX.",
    siteName: "Safesplayce",
    tagline: "A Quiet Place To Be Together"
  },

  // ── Supabase — create free project at supabase.com ──
  supabaseUrl: "https://YOUR_PROJECT_ID.supabase.co",
  supabaseAnonKey: "YOUR_SUPABASE_ANON_KEY",

  // ── Stripe — dashboard.stripe.com ──
  stripePublishableKey: "pk_test_51YOUR_TEST_KEY",
  // Map cart names to Stripe Price IDs (Products → Copy Price ID)
  stripePriceIds: {
    "Brain Teasers PDF": "price_1brainTeasers199",
    "Cozy Evenings Pack": "price_1cozyPack499",
    "Single Puzzle Drop": "price_1single149",
    "Gift Puzzle Pack": "price_1gift499",
    "Monthly Puzzle Subscription": "price_1monthly799_month",
    "Breathe Tee": "price_1tee2800",
    "Quiet Mind Hoodie": "price_1hoodie4800",
    "Safesplayce Mug": "price_1mug1600",
    "Journal + Stickers": "price_1journal2200",
    "Printed + PDF Bundle": "price_1printed999",
    // Volume 2 — new
    "Self-Compassion Vol. 2 PDF": "price_1vol2self199",
    "Sleep & Dreams Vol. 2 PDF": "price_1vol2sleep199",
    "Vol. 2 Bundle (Both PDFs)": "price_1vol2bundle349"
  },
  // Stripe Checkout settings — now with tax + shipping
  stripeSettings: {
    allowPromotionCodes: true,          // lets you create 10% off codes in Stripe Dashboard
    collectShippingAddress: true,       // collects shipping for swag; set false if you only sell PDFs
    collectTaxAutomatically: true,      // requires Stripe Tax to be enabled in Dashboard → Tax
    shippingRates: [                    // create Shipping Rates in Stripe Dashboard → copy IDs
      // "shr_1standardTX5",            // Example: Standard (2-5 days) — Dallas, TX flat $5
      // "shr_1expressTX12"             // Example: Express flat $12
    ],
    // If you sell only digital PDFs, Stripe can skip shipping — we auto-detect cart and disable shipping for PDF-only carts
    digitalOnlySkipsShipping: true
  },
  stripeFallbackPaymentLink: "https://buy.stripe.com/test_YOUR_LINK",

  // ── Shopify (optional alternative for swag) ──
  // If you prefer Shopify for physical swag, fill these and we'll show a Shopify Buy Button alongside Stripe
  shopify: {
    enabled: false, // set true to show Shopify buttons
    domain: "your-store.myshopify.com", // e.g. safesplayce.myshopify.com
    storefrontAccessToken: "YOUR_STOREFRONT_TOKEN", // Storefront API token (Headless → Create Storefront token)
    collectionHandle: "all", // or "swag" — which collection to show
    // Map product handles if you want per-item buttons: { "Breathe Tee": "breathe-tee", ... }
    productHandles: {
      "Breathe Tee": "breathe-tee",
      "Quiet Mind Hoodie": "quiet-mind-hoodie",
      "Safesplayce Mug": "safesplayce-mug",
      "Journal + Stickers": "journal-sticker-pack"
    }
  },

  // ── Email — pick one ──
  mailchimpUrl: "https://YOUR_DC.usXX.list-manage.com/subscribe/post?u=YOUR_U&id=YOUR_ID",
  convertkitFormUrl: "https://app.convertkit.com/forms/YOUR_FORM_ID/subscriptions",
  useSupabaseForEmails: true, // easiest — no extra service, exports from Supabase

  // ── Puzzles — direct PDF links (hosted in /puzzles/) ──
  puzzles: {
    gentleFree: "puzzles/gentle-words-vol1.pdf",
    gentleVol2Self: "puzzles/gentle-words-vol2-self-compassion.pdf",
    gentleVol2Sleep: "puzzles/gentle-words-vol2-sleep.pdf",
    brainTeasers: "puzzles/brain-teasers-quiet-nights.pdf",
    cozyPack: "puzzles/cozy-evenings-pack.pdf"
  },

  // ── Shipping / Tax copy ──
  shipping: {
    freeOver: 60,
    flatRateNote: "Flat $5 standard • $12 express • Free over $60 • Ships from Dallas, TX (2–5 days)",
    digitalNote: "PDFs are instant download — no shipping needed"
  },

  // ── Owner / Creator access (private — never linked from the public site) ──
  owner: {
    // Lock the creator login (/admin) to these emails. Empty list = any email in demo mode.
    emails: [], // e.g. ["you@email.com"]
    // Creator passcode (used while Supabase isn't connected). CHANGE THIS before going live!
    demoCode: "OWNER2026",
    // Optional display name shown after sign-in
    displayName: "Creator"
  },

  // ── Moderation ──
  moderation: {
    // Who can log into moderators.html (comma-separated emails). Leave empty to allow any code in demo; in production, lock to real emails.
    allowedEmails: [], // e.g. ["you@email.com", "trusted1@gmail.com"]
    // Demo access code (for when Supabase not connected). Share this privately with moderators.
    demoCode: "SAFE2026",
    // Auto-hide message after N reports (for safety). Moderator still reviews.
    autoHideAfterReports: 2,
    // Roles and what they can do
    roles: {
      owner: ["all"], // you: add/remove moderators, all actions
      lead: ["hide","mute","ban","system_msg","resolve","close_room"],
      moderator: ["hide","mute","resolve","system_msg"]
    },
    // Crisis escalation — if someone shares self-harm, moderators see this banner + resources
    crisisMessage: "You deserve support right now — you are not alone. If you need help, call/text 988, text HOME to 741741, or tell a trusted person. A moderator is here to listen, not to diagnose."
  }
};
